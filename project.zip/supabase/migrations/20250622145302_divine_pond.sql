/*
  # Criação das tabelas principais do sistema

  1. Novas Tabelas
    - `clients` - Armazena informações dos clientes
    - `projects` - Armazena projetos dos clientes
    - `transactions` - Armazena transações financeiras
    - `user_cycles` - Armazena ciclos de trabalho dos usuários

  2. Segurança
    - Habilita RLS em todas as tabelas
    - Adiciona políticas para usuários autenticados acessarem apenas seus próprios dados
*/

-- Tabela de clientes
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  company text,
  address text NOT NULL,
  cnpj text NOT NULL,
  logo_url text,
  total_projects integer DEFAULT 0,
  total_revenue decimal DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Tabela de projetos
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE NOT NULL,
  client_name text NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  status text NOT NULL CHECK (status IN ('pending', 'in-progress', 'completed', 'cancelled')),
  priority text NOT NULL CHECK (priority IN ('low', 'medium', 'high')),
  value decimal NOT NULL,
  deadline timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  payment_received boolean DEFAULT false,
  payment_date timestamptz
);

-- Tabela de transações
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL CHECK (type IN ('income', 'expense')),
  description text NOT NULL,
  amount decimal NOT NULL,
  category text NOT NULL,
  date timestamptz NOT NULL,
  project_id uuid REFERENCES projects(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- Tabela de ciclos do usuário
CREATE TABLE IF NOT EXISTS user_cycles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  start_date timestamptz NOT NULL,
  end_date timestamptz NOT NULL,
  cycle_number integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_cycles ENABLE ROW LEVEL SECURITY;

-- Políticas para clients
CREATE POLICY "Users can manage their own clients"
  ON clients
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Políticas para projects
CREATE POLICY "Users can manage their own projects"
  ON projects
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Políticas para transactions
CREATE POLICY "Users can manage their own transactions"
  ON transactions
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Políticas para user_cycles
CREATE POLICY "Users can manage their own cycles"
  ON user_cycles
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Índices para melhor performance
CREATE INDEX IF NOT EXISTS clients_user_id_idx ON clients(user_id);
CREATE INDEX IF NOT EXISTS projects_user_id_idx ON projects(user_id);
CREATE INDEX IF NOT EXISTS projects_client_id_idx ON projects(client_id);
CREATE INDEX IF NOT EXISTS transactions_user_id_idx ON transactions(user_id);
CREATE INDEX IF NOT EXISTS transactions_project_id_idx ON transactions(project_id);
CREATE INDEX IF NOT EXISTS user_cycles_user_id_idx ON user_cycles(user_id);