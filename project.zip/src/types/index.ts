export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  address: string;
  cnpj: string;
  logoUrl?: string;
  createdAt: Date;
  totalProjects: number;
  totalRevenue: number;
}

export interface Project {
  id: string;
  clientId: string;
  clientName: string;
  title: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
  priority: 'low' | 'medium' | 'high';
  value: number;
  deadline: Date;
  createdAt: Date;
  completedAt?: Date;
  paymentReceived?: boolean;
  paymentDate?: Date;
}

export interface Transaction {
  id: string;
  type: 'income' | 'expense';
  description: string;
  amount: number;
  category: string;
  date: Date;
  projectId?: string;
}

export interface Stats {
  totalClients: number;
  activeProjects: number;
  completedProjects: number;
  totalRevenue: number;
  monthlyRevenue: number;
  pendingPayments: number;
}

export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: Date;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
}