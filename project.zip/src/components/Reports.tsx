import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Calendar, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  Briefcase, 
  Eye,
  BarChart3,
  PieChart,
  Filter,
  RefreshCw
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { generateAdvancedReport } from '../utils/advancedPdfGenerator';

export default function Reports() {
  const { state } = useApp();
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [reportType, setReportType] = useState('complete');
  const [generating, setGenerating] = useState(false);
  const [previewData, setPreviewData] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('overview');

  const months = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i);

  const reportTypes = [
    { id: 'complete', name: 'Relatório Completo', description: 'Análise detalhada de todos os aspectos' },
    { id: 'financial', name: 'Relatório Financeiro', description: 'Foco em receitas, despesas e lucros' },
    { id: 'projects', name: 'Relatório de Projetos', description: 'Status e performance dos projetos' },
    { id: 'clients', name: 'Relatório de Clientes', description: 'Análise de relacionamento com clientes' }
  ];

  const getMonthlyData = (month: number, year: number) => {
    const startDate = new Date(year, month, 1);
    const endDate = new Date(year, month + 1, 0);

    // Filtrar dados do período
    const monthlyTransactions = state.transactions.filter(transaction => {
      const transactionDate = new Date(transaction.date);
      return transactionDate >= startDate && transactionDate <= endDate;
    });

    const monthlyProjects = state.projects.filter(project => {
      const projectDate = new Date(project.createdAt);
      return projectDate >= startDate && projectDate <= endDate;
    });

    // Análises avançadas
    const incomeByCategory = monthlyTransactions
      .filter(t => t.type === 'income')
      .reduce((acc, transaction) => {
        acc[transaction.category] = (acc[transaction.category] || 0) + transaction.amount;
        return acc;
      }, {} as Record<string, number>);

    const expensesByCategory = monthlyTransactions
      .filter(t => t.type === 'expense')
      .reduce((acc, transaction) => {
        acc[transaction.category] = (acc[transaction.category] || 0) + transaction.amount;
        return acc;
      }, {} as Record<string, number>);

    const projectsByStatus = monthlyProjects.reduce((acc, project) => {
      acc[project.status] = (acc[project.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const projectsByPriority = monthlyProjects.reduce((acc, project) => {
      acc[project.priority] = (acc[project.priority] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Análise de clientes
    const clientsData = monthlyProjects.reduce((acc, project) => {
      if (!acc[project.clientId]) {
        const client = state.clients.find(c => c.id === project.clientId);
        acc[project.clientId] = {
          name: client?.name || 'Cliente não encontrado',
          projects: 0,
          revenue: 0
        };
      }
      acc[project.clientId].projects++;
      acc[project.clientId].revenue += project.value;
      return acc;
    }, {} as Record<string, any>);

    // Análise temporal
    const dailyRevenue = monthlyTransactions
      .filter(t => t.type === 'income')
      .reduce((acc, transaction) => {
        const day = new Date(transaction.date).getDate();
        acc[day] = (acc[day] || 0) + transaction.amount;
        return acc;
      }, {} as Record<number, number>);

    const totalIncome = Object.values(incomeByCategory).reduce((sum, amount) => sum + amount, 0);
    const totalExpenses = Object.values(expensesByCategory).reduce((sum, amount) => sum + amount, 0);
    const profit = totalIncome - totalExpenses;

    // Comparação com período anterior
    const prevMonth = month === 0 ? 11 : month - 1;
    const prevYear = month === 0 ? year - 1 : year;
    const prevStartDate = new Date(prevYear, prevMonth, 1);
    const prevEndDate = new Date(prevYear, prevMonth + 1, 0);

    const prevTransactions = state.transactions.filter(t => {
      const date = new Date(t.date);
      return date >= prevStartDate && date <= prevEndDate;
    });

    const prevIncome = prevTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);

    const incomeGrowth = prevIncome > 0 ? ((totalIncome - prevIncome) / prevIncome) * 100 : 0;

    return {
      period: `${months[month]} ${year}`,
      startDate,
      endDate,
      totalIncome,
      totalExpenses,
      profit,
      incomeGrowth,
      incomeByCategory,
      expensesByCategory,
      projectsByStatus,
      projectsByPriority,
      clientsData,
      dailyRevenue,
      activeClients: Object.keys(clientsData).length,
      totalProjects: monthlyProjects.length,
      transactions: monthlyTransactions,
      projects: monthlyProjects,
      avgProjectValue: monthlyProjects.length > 0 ? monthlyProjects.reduce((sum, p) => sum + p.value, 0) / monthlyProjects.length : 0,
      completionRate: monthlyProjects.length > 0 ? (monthlyProjects.filter(p => p.status === 'completed').length / monthlyProjects.length) * 100 : 0
    };
  };

  const handleGenerateReport = async () => {
    setGenerating(true);
    try {
      const data = getMonthlyData(selectedMonth, selectedYear);
      await generateAdvancedReport(data, reportType);
    } catch (error) {
      console.error('Erro ao gerar relatório:', error);
      alert('Erro ao gerar relatório. Tente novamente.');
    } finally {
      setGenerating(false);
    }
  };

  const handlePreview = () => {
    const data = getMonthlyData(selectedMonth, selectedYear);
    setPreviewData(data);
  };

  const formatCurrency = (amount: number) => {
    return `R$ ${amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
  };

  const getStatusText = (status: string) => {
    const statusMap: Record<string, string> = {
      'pending': 'Pendente',
      'in-progress': 'Em Andamento',
      'completed': 'Finalizado',
      'cancelled': 'Cancelado'
    };
    return statusMap[status] || status;
  };

  const getPriorityText = (priority: string) => {
    const priorityMap: Record<string, string> = {
      'high': 'Alta',
      'medium': 'Média',
      'low': 'Baixa'
    };
    return priorityMap[priority] || priority;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl">
            <BarChart3 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Central de Relatórios</h1>
            <p className="text-white/60">Análises avançadas e insights detalhados</p>
          </div>
        </div>
        <button
          onClick={() => window.location.reload()}
          className="p-3 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-colors"
        >
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>

      {/* Report Configuration */}
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
        <div className="flex items-center space-x-2 mb-6">
          <Filter className="w-5 h-5 text-blue-400" />
          <h3 className="text-xl font-semibold text-white">Configuração do Relatório</h3>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Period Selection */}
          <div className="lg:col-span-2 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-white/70 text-sm font-medium mb-2">Mês</label>
                <select
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {months.map((month, index) => (
                    <option key={index} value={index} className="bg-gray-800">
                      {month}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-white/70 text-sm font-medium mb-2">Ano</label>
                <select
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {years.map(year => (
                    <option key={year} value={year} className="bg-gray-800">
                      {year}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Report Type Selection */}
            <div>
              <label className="block text-white/70 text-sm font-medium mb-3">Tipo de Relatório</label>
              <div className="grid grid-cols-1 gap-2">
                {reportTypes.map(type => (
                  <label key={type.id} className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer">
                    <input
                      type="radio"
                      name="reportType"
                      value={type.id}
                      checked={reportType === type.id}
                      onChange={(e) => setReportType(e.target.value)}
                      className="text-blue-500 focus:ring-blue-500"
                    />
                    <div>
                      <p className="text-white font-medium">{type.name}</p>
                      <p className="text-white/60 text-xs">{type.description}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="lg:col-span-2 flex flex-col justify-center space-y-4">
            <button
              onClick={handlePreview}
              className="w-full px-6 py-4 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-colors flex items-center justify-center space-x-2"
            >
              <Eye className="w-5 h-5" />
              <span>Visualizar Prévia</span>
            </button>
            
            <button
              onClick={handleGenerateReport}
              disabled={generating}
              className="w-full px-6 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200 flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {generating ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Download className="w-5 h-5" />
                  <span>Gerar PDF Avançado</span>
                </>
              )}
            </button>

            <div className="text-center text-white/60 text-sm">
              <p>Relatório será gerado com gráficos,</p>
              <p>análises comparativas e insights</p>
            </div>
          </div>
        </div>
      </div>

      {/* Preview */}
      {previewData && (
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl border border-white/20 overflow-hidden">
          <div className="p-6 border-b border-white/20">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold text-white">Prévia Avançada - {previewData.period}</h3>
              <div className="flex space-x-2">
                {['overview', 'financial', 'projects', 'clients'].map(tab => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeTab === tab
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'text-white/60 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    {tab === 'overview' && 'Visão Geral'}
                    {tab === 'financial' && 'Financeiro'}
                    {tab === 'projects' && 'Projetos'}
                    {tab === 'clients' && 'Clientes'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="p-6">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* KPIs */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-xl p-4 border border-green-500/30">
                    <div className="flex items-center space-x-3">
                      <TrendingUp className="w-8 h-8 text-green-400" />
                      <div>
                        <p className="text-green-400 text-sm font-medium">Receita Total</p>
                        <p className="text-white text-xl font-bold">{formatCurrency(previewData.totalIncome)}</p>
                        {previewData.incomeGrowth !== 0 && (
                          <p className={`text-xs ${previewData.incomeGrowth > 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {previewData.incomeGrowth > 0 ? '+' : ''}{previewData.incomeGrowth.toFixed(1)}% vs mês anterior
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-red-500/20 to-pink-500/20 rounded-xl p-4 border border-red-500/30">
                    <div className="flex items-center space-x-3">
                      <TrendingDown className="w-8 h-8 text-red-400" />
                      <div>
                        <p className="text-red-400 text-sm font-medium">Despesas</p>
                        <p className="text-white text-xl font-bold">{formatCurrency(previewData.totalExpenses)}</p>
                        <p className="text-xs text-white/60">
                          {previewData.totalIncome > 0 ? ((previewData.totalExpenses / previewData.totalIncome) * 100).toFixed(1) : '0'}% da receita
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className={`bg-gradient-to-r ${previewData.profit >= 0 ? 'from-blue-500/20 to-cyan-500/20 border-blue-500/30' : 'from-red-500/20 to-pink-500/20 border-red-500/30'} rounded-xl p-4 border`}>
                    <div className="flex items-center space-x-3">
                      <DollarSign className={`w-8 h-8 ${previewData.profit >= 0 ? 'text-blue-400' : 'text-red-400'}`} />
                      <div>
                        <p className={`text-sm font-medium ${previewData.profit >= 0 ? 'text-blue-400' : 'text-red-400'}`}>Lucro Líquido</p>
                        <p className="text-white text-xl font-bold">{formatCurrency(previewData.profit)}</p>
                        <p className="text-xs text-white/60">
                          Margem: {previewData.totalIncome > 0 ? ((previewData.profit / previewData.totalIncome) * 100).toFixed(1) : '0'}%
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-purple-500/20 to-indigo-500/20 rounded-xl p-4 border border-purple-500/30">
                    <div className="flex items-center space-x-3">
                      <Briefcase className="w-8 h-8 text-purple-400" />
                      <div>
                        <p className="text-purple-400 text-sm font-medium">Projetos</p>
                        <p className="text-white text-xl font-bold">{previewData.totalProjects}</p>
                        <p className="text-xs text-white/60">
                          Taxa conclusão: {previewData.completionRate.toFixed(1)}%
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Performance Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white/5 rounded-xl p-4">
                    <h4 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
                      <PieChart className="w-5 h-5 text-blue-400" />
                      <span>Métricas de Performance</span>
                    </h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-white/70">Valor Médio por Projeto</span>
                        <span className="text-white font-semibold">{formatCurrency(previewData.avgProjectValue)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/70">Clientes Ativos</span>
                        <span className="text-white font-semibold">{previewData.activeClients}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/70">Receita por Cliente</span>
                        <span className="text-white font-semibold">
                          {formatCurrency(previewData.activeClients > 0 ? previewData.totalIncome / previewData.activeClients : 0)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 rounded-xl p-4">
                    <h4 className="text-lg font-semibold text-white mb-4">Status dos Projetos</h4>
                    <div className="space-y-3">
                      {Object.entries(previewData.projectsByStatus).map(([status, count]) => (
                        <div key={status} className="flex justify-between items-center">
                          <span className="text-white/70">{getStatusText(status)}</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-white font-semibold">{count as number}</span>
                            <div className="w-16 bg-white/20 rounded-full h-2">
                              <div 
                                className="bg-blue-400 h-2 rounded-full" 
                                style={{ width: `${((count as number) / previewData.totalProjects) * 100}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Financial Tab */}
            {activeTab === 'financial' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Income by Category */}
                  {Object.keys(previewData.incomeByCategory).length > 0 && (
                    <div className="bg-white/5 rounded-xl p-4">
                      <h4 className="text-lg font-semibold text-white mb-4 text-green-400">Receitas por Categoria</h4>
                      <div className="space-y-3">
                        {Object.entries(previewData.incomeByCategory)
                          .sort(([,a], [,b]) => (b as number) - (a as number))
                          .map(([category, amount]) => (
                          <div key={category} className="flex justify-between items-center p-3 bg-green-500/10 rounded-lg border border-green-500/20">
                            <span className="text-white">{category}</span>
                            <div className="text-right">
                              <span className="text-green-400 font-semibold block">{formatCurrency(amount as number)}</span>
                              <span className="text-green-400/60 text-xs">
                                {((amount as number / previewData.totalIncome) * 100).toFixed(1)}%
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Expenses by Category */}
                  {Object.keys(previewData.expensesByCategory).length > 0 && (
                    <div className="bg-white/5 rounded-xl p-4">
                      <h4 className="text-lg font-semibold text-white mb-4 text-red-400">Despesas por Categoria</h4>
                      <div className="space-y-3">
                        {Object.entries(previewData.expensesByCategory)
                          .sort(([,a], [,b]) => (b as number) - (a as number))
                          .map(([category, amount]) => (
                          <div key={category} className="flex justify-between items-center p-3 bg-red-500/10 rounded-lg border border-red-500/20">
                            <span className="text-white">{category}</span>
                            <div className="text-right">
                              <span className="text-red-400 font-semibold block">{formatCurrency(amount as number)}</span>
                              <span className="text-red-400/60 text-xs">
                                {((amount as number / previewData.totalExpenses) * 100).toFixed(1)}%
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Daily Revenue Chart Simulation */}
                <div className="bg-white/5 rounded-xl p-4">
                  <h4 className="text-lg font-semibold text-white mb-4">Receita Diária do Mês</h4>
                  <div className="grid grid-cols-7 gap-2">
                    {Array.from({ length: 31 }, (_, i) => i + 1).map(day => {
                      const revenue = previewData.dailyRevenue[day] || 0;
                      const maxRevenue = Math.max(...Object.values(previewData.dailyRevenue));
                      const height = maxRevenue > 0 ? (revenue / maxRevenue) * 100 : 0;
                      
                      return (
                        <div key={day} className="flex flex-col items-center space-y-1">
                          <div className="w-8 h-16 bg-white/10 rounded flex items-end">
                            <div 
                              className="w-full bg-blue-400 rounded"
                              style={{ height: `${height}%` }}
                            />
                          </div>
                          <span className="text-xs text-white/60">{day}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Projects Tab */}
            {activeTab === 'projects' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white/5 rounded-xl p-4">
                    <h4 className="text-lg font-semibold text-white mb-4">Projetos por Prioridade</h4>
                    <div className="space-y-3">
                      {Object.entries(previewData.projectsByPriority).map(([priority, count]) => (
                        <div key={priority} className="flex justify-between items-center">
                          <span className="text-white/70">{getPriorityText(priority)}</span>
                          <span className="text-white font-semibold">{count as number}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white/5 rounded-xl p-4">
                    <h4 className="text-lg font-semibold text-white mb-4">Análise de Performance</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-white/70">Taxa de Conclusão</span>
                        <span className="text-green-400 font-semibold">{previewData.completionRate.toFixed(1)}%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/70">Valor Médio</span>
                        <span className="text-white font-semibold">{formatCurrency(previewData.avgProjectValue)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/70">Receita Total</span>
                        <span className="text-blue-400 font-semibold">
                          {formatCurrency(previewData.projects.reduce((sum: number, p: any) => sum + p.value, 0))}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Projects */}
                {previewData.projects.length > 0 && (
                  <div className="bg-white/5 rounded-xl p-4">
                    <h4 className="text-lg font-semibold text-white mb-4">Projetos do Período</h4>
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {previewData.projects.map((project: any) => (
                        <div key={project.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                          <div className="flex-1">
                            <p className="text-white font-medium">{project.title}</p>
                            <p className="text-white/60 text-sm">{project.clientName}</p>
                          </div>
                          <div className="flex items-center space-x-3">
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              project.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                              project.status === 'in-progress' ? 'bg-blue-500/20 text-blue-400' :
                              project.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                              'bg-red-500/20 text-red-400'
                            }`}>
                              {getStatusText(project.status)}
                            </span>
                            <span className="text-white font-semibold">{formatCurrency(project.value)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Clients Tab */}
            {activeTab === 'clients' && (
              <div className="space-y-6">
                {Object.keys(previewData.clientsData).length > 0 ? (
                  <div className="bg-white/5 rounded-xl p-4">
                    <h4 className="text-lg font-semibold text-white mb-4">Performance por Cliente</h4>
                    <div className="space-y-3">
                      {Object.entries(previewData.clientsData)
                        .sort(([,a], [,b]) => (b as any).revenue - (a as any).revenue)
                        .map(([clientId, data]) => (
                        <div key={clientId} className="flex items-center justify-between p-4 bg-white/5 rounded-lg border border-white/10">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                              <Users className="w-5 h-5 text-white" />
                            </div>
                            <div>
                              <p className="text-white font-medium">{(data as any).name}</p>
                              <p className="text-white/60 text-sm">{(data as any).projects} projeto(s)</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-white font-semibold">{formatCurrency((data as any).revenue)}</p>
                            <p className="text-white/60 text-sm">
                              {formatCurrency((data as any).revenue / (data as any).projects)} por projeto
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-white/50">
                    <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Nenhum cliente ativo no período</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          onClick={() => {
            setSelectedMonth(new Date().getMonth());
            setSelectedYear(new Date().getFullYear());
            handlePreview();
          }}
          className="p-6 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-xl border border-blue-500/30 hover:from-blue-500/30 hover:to-cyan-500/30 transition-all duration-200 text-left group"
        >
          <Calendar className="w-8 h-8 text-blue-400 mb-3 group-hover:scale-110 transition-transform" />
          <h4 className="text-white font-semibold text-lg">Mês Atual</h4>
          <p className="text-white/60 text-sm">Análise do período corrente</p>
        </button>

        <button
          onClick={() => {
            const lastMonth = new Date();
            lastMonth.setMonth(lastMonth.getMonth() - 1);
            setSelectedMonth(lastMonth.getMonth());
            setSelectedYear(lastMonth.getFullYear());
            handlePreview();
          }}
          className="p-6 bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-xl border border-green-500/30 hover:from-green-500/30 hover:to-emerald-500/30 transition-all duration-200 text-left group"
        >
          <TrendingUp className="w-8 h-8 text-green-400 mb-3 group-hover:scale-110 transition-transform" />
          <h4 className="text-white font-semibold text-lg">Mês Anterior</h4>
          <p className="text-white/60 text-sm">Comparação de performance</p>
        </button>

        <button
          onClick={() => {
            const threeMonthsAgo = new Date();
            threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
            setSelectedMonth(threeMonthsAgo.getMonth());
            setSelectedYear(threeMonthsAgo.getFullYear());
            handlePreview();
          }}
          className="p-6 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl border border-purple-500/30 hover:from-purple-500/30 hover:to-pink-500/30 transition-all duration-200 text-left group"
        >
          <FileText className="w-8 h-8 text-purple-400 mb-3 group-hover:scale-110 transition-transform" />
          <h4 className="text-white font-semibold text-lg">Análise Trimestral</h4>
          <p className="text-white/60 text-sm">Visão de longo prazo</p>
        </button>
      </div>
    </div>
  );
}