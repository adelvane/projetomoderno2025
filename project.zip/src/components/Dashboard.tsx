import React from 'react';
import { TrendingUp, Users, Briefcase, DollarSign, Clock, CheckCircle, Calendar, RotateCcw } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

export default function Dashboard() {
  const { state, dispatch } = useApp();

  const cards = [
    {
      title: 'Total de Clientes',
      value: state.stats.totalClients,
      icon: Users,
      color: 'from-blue-500 to-cyan-500',
      bgColor: 'bg-blue-500/10',
    },
    {
      title: 'Projetos Ativos',
      value: state.stats.activeProjects,
      icon: Clock,
      color: 'from-orange-500 to-red-500',
      bgColor: 'bg-orange-500/10',
    },
    {
      title: 'Projetos Finalizados',
      value: state.stats.completedProjects,
      icon: CheckCircle,
      color: 'from-green-500 to-emerald-500',
      bgColor: 'bg-green-500/10',
    },
    {
      title: 'Receita Total',
      value: `R$ ${state.stats.totalRevenue.toLocaleString('pt-BR')}`,
      icon: DollarSign,
      color: 'from-purple-500 to-pink-500',
      bgColor: 'bg-purple-500/10',
    },
  ];

  const recentProjects = state.projects
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500/20 text-yellow-400';
      case 'in-progress': return 'bg-blue-500/20 text-blue-400';
      case 'completed': return 'bg-green-500/20 text-green-400';
      case 'cancelled': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Pendente';
      case 'in-progress': return 'Em Andamento';
      case 'completed': return 'Finalizado';
      case 'cancelled': return 'Cancelado';
      default: return status;
    }
  };

  const handleNewCycle = () => {
    if (confirm('Tem certeza que deseja iniciar um novo ciclo de 30 dias? Isso irá resetar as estatísticas mensais.')) {
      dispatch({ type: 'START_NEW_CYCLE' });
    }
  };

  const daysUntilCycleEnd = Math.ceil(
    (state.currentCycle.endDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
  );

  return (
    <div className="space-y-6">
      {/* Current Cycle Info */}
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-purple-500/20 rounded-xl">
              <Calendar className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">Ciclo Atual</h3>
              <p className="text-white/60 text-sm">
                {state.currentCycle.startDate.toLocaleDateString('pt-BR')} - {state.currentCycle.endDate.toLocaleDateString('pt-BR')}
              </p>
              <p className="text-white/50 text-xs mt-1">
                {daysUntilCycleEnd > 0 ? `${daysUntilCycleEnd} dias restantes` : 'Ciclo expirado'}
              </p>
            </div>
          </div>
          <button
            onClick={handleNewCycle}
            className="px-4 py-2 bg-purple-500/20 text-purple-400 rounded-lg hover:bg-purple-500/30 transition-colors flex items-center space-x-2"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Novo Ciclo</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div
              key={index}
              className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-300 group"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-xl ${card.bgColor}`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <TrendingUp className="w-5 h-5 text-green-400 group-hover:scale-110 transition-transform" />
              </div>
              <h3 className="text-sm font-medium text-white/70 mb-1">{card.title}</h3>
              <p className="text-2xl font-bold text-white">{card.value}</p>
            </div>
          );
        })}
      </div>

      {/* Recent Projects */}
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-semibold text-white mb-6">Projetos Recentes</h3>
        <div className="space-y-4">
          {recentProjects.length === 0 ? (
            <div className="text-center py-8 text-white/50">
              <Briefcase className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Nenhum projeto encontrado</p>
            </div>
          ) : (
            recentProjects.map((project) => (
              <div
                key={project.id}
                className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10 hover:bg-white/10 transition-all duration-200"
              >
                <div className="flex-1">
                  <h4 className="font-medium text-white mb-1">{project.title}</h4>
                  <p className="text-sm text-white/60">{project.clientName}</p>
                </div>
                <div className="flex items-center space-x-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(project.status)}`}>
                    {getStatusText(project.status)}
                  </span>
                  <span className="text-white font-semibold">
                    R$ {project.value.toLocaleString('pt-BR')}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Financial Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
          <h3 className="text-xl font-semibold text-white mb-4">Receita do Ciclo</h3>
          <div className="text-3xl font-bold text-green-400 mb-2">
            R$ {state.stats.monthlyRevenue.toLocaleString('pt-BR')}
          </div>
          <p className="text-white/60">Ciclo atual ({daysUntilCycleEnd} dias restantes)</p>
        </div>

        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
          <h3 className="text-xl font-semibold text-white mb-4">Pagamentos Pendentes</h3>
          <div className="text-3xl font-bold text-yellow-400 mb-2">
            R$ {state.stats.pendingPayments.toLocaleString('pt-BR')}
          </div>
          <p className="text-white/60">Aguardando recebimento</p>
        </div>
      </div>
    </div>
  );
}