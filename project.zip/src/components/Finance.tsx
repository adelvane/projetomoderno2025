import React, { useState } from 'react';
import { Plus, TrendingUp, TrendingDown, DollarSign, Calendar, Edit2, Trash2, Check, CreditCard } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { Transaction } from '../types';
import StripePayment from './StripePayment';

export default function Finance() {
  const { state, dispatch } = useApp();
  const [showForm, setShowForm] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [filterType, setFilterType] = useState('all');
  const [showPayment, setShowPayment] = useState<{ projectId: string; amount: number; description: string } | null>(null);

  const [formData, setFormData] = useState({
    type: 'income' as Transaction['type'],
    description: '',
    amount: '',
    category: '',
    date: new Date().toISOString().split('T')[0],
    projectId: '',
  });

  const categories = {
    income: ['Projeto', 'Consultoria', 'Manutenção', 'Outros'],
    expense: ['Equipamentos', 'Software', 'Marketing', 'Escritório', 'Outros'],
  };

  const filteredTransactions = state.transactions.filter(transaction => {
    if (filterType === 'all') return true;
    return transaction.type === filterType;
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const totalIncome = state.transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpenses = state.transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const balance = totalIncome - totalExpenses;

  // Projetos finalizados sem pagamento recebido
  const pendingPayments = state.projects.filter(p => 
    p.status === 'completed' && !p.paymentReceived
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingTransaction) {
      const updatedTransaction: Transaction = {
        ...editingTransaction,
        ...formData,
        amount: parseFloat(formData.amount),
        date: new Date(formData.date),
        projectId: formData.projectId || undefined,
      };
      dispatch({ type: 'UPDATE_TRANSACTION', payload: updatedTransaction });
    } else {
      const newTransaction: Transaction = {
        id: Math.random().toString(36).substr(2, 9),
        ...formData,
        amount: parseFloat(formData.amount),
        date: new Date(formData.date),
        projectId: formData.projectId || undefined,
      };
      dispatch({ type: 'ADD_TRANSACTION', payload: newTransaction });
    }

    resetForm();
  };

  const resetForm = () => {
    setFormData({
      type: 'income',
      description: '',
      amount: '',
      category: '',
      date: new Date().toISOString().split('T')[0],
      projectId: '',
    });
    setEditingTransaction(null);
    setShowForm(false);
  };

  const handleEdit = (transaction: Transaction) => {
    setFormData({
      type: transaction.type,
      description: transaction.description,
      amount: transaction.amount.toString(),
      category: transaction.category,
      date: transaction.date.toISOString().split('T')[0],
      projectId: transaction.projectId || '',
    });
    setEditingTransaction(transaction);
    setShowForm(true);
  };

  const handleDelete = (transactionId: string) => {
    if (confirm('Tem certeza que deseja excluir esta transação?')) {
      dispatch({ type: 'DELETE_TRANSACTION', payload: transactionId });
    }
  };

  const handleReceivePayment = (projectId: string) => {
    const project = state.projects.find(p => p.id === projectId);
    if (project) {
      // Marcar projeto como pago
      const updatedProject = {
        ...project,
        paymentReceived: true,
        paymentDate: new Date(),
      };
      dispatch({ type: 'UPDATE_PROJECT', payload: updatedProject });

      // Criar transação de receita
      const newTransaction: Transaction = {
        id: Math.random().toString(36).substr(2, 9),
        type: 'income',
        description: `Pagamento recebido - ${project.title}`,
        amount: project.value,
        category: 'Projeto',
        date: new Date(),
        projectId: project.id,
      };
      dispatch({ type: 'ADD_TRANSACTION', payload: newTransaction });
    }
  };

  const handleStripePayment = (projectId: string) => {
    const project = state.projects.find(p => p.id === projectId);
    if (project) {
      setShowPayment({
        projectId,
        amount: project.value,
        description: `Pagamento do projeto: ${project.title}`
      });
    }
  };

  const handlePaymentSuccess = () => {
    if (showPayment) {
      handleReceivePayment(showPayment.projectId);
      setShowPayment(null);
    }
  };

  const handlePaymentCancel = () => {
    setShowPayment(null);
  };

  return (
    <div className="space-y-6">
      {/* Stripe Payment Modal */}
      {showPayment && (
        <StripePayment
          amount={showPayment.amount}
          description={showPayment.description}
          onSuccess={handlePaymentSuccess}
          onCancel={handlePaymentCancel}
        />
      )}

      {/* Financial Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-green-500/20 rounded-xl">
              <TrendingUp className="w-6 h-6 text-green-400" />
            </div>
            <span className="text-green-400 text-sm font-medium">+12.5%</span>
          </div>
          <h3 className="text-sm font-medium text-white/70 mb-1">Receitas</h3>
          <p className="text-2xl font-bold text-white">
            R$ {totalIncome.toLocaleString('pt-BR')}
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-red-500/20 rounded-xl">
              <TrendingDown className="w-6 h-6 text-red-400" />
            </div>
            <span className="text-red-400 text-sm font-medium">-8.2%</span>
          </div>
          <h3 className="text-sm font-medium text-white/70 mb-1">Despesas</h3>
          <p className="text-2xl font-bold text-white">
            R$ {totalExpenses.toLocaleString('pt-BR')}
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-500/20 rounded-xl">
              <DollarSign className="w-6 h-6 text-blue-400" />
            </div>
            <span className={`text-sm font-medium ${balance >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {balance >= 0 ? '+' : ''}{totalIncome > 0 ? ((balance / totalIncome) * 100).toFixed(1) : '0'}%
            </span>
          </div>
          <h3 className="text-sm font-medium text-white/70 mb-1">Saldo</h3>
          <p className={`text-2xl font-bold ${balance >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            R$ {balance.toLocaleString('pt-BR')}
          </p>
        </div>
      </div>

      {/* Pending Payments */}
      {pendingPayments.length > 0 && (
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl border border-white/20 overflow-hidden">
          <div className="p-6 border-b border-white/20">
            <h3 className="text-xl font-semibold text-white">Pagamentos Pendentes</h3>
            <p className="text-white/60 text-sm mt-1">Projetos finalizados aguardando pagamento</p>
          </div>
          <div className="divide-y divide-white/10">
            {pendingPayments.map((project) => (
              <div key={project.id} className="p-6 hover:bg-white/5 transition-colors">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">{project.title}</h4>
                    <p className="text-sm text-white/60">{project.clientName}</p>
                    <p className="text-xs text-white/50 mt-1">
                      Finalizado em {project.completedAt ? new Date(project.completedAt).toLocaleDateString('pt-BR') : 'Data não disponível'}
                    </p>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="text-lg font-semibold text-yellow-400">
                      R$ {project.value.toLocaleString('pt-BR')}
                    </span>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleStripePayment(project.id)}
                        className="px-4 py-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-colors flex items-center space-x-2"
                      >
                        <CreditCard className="w-4 h-4" />
                        <span>Pagar</span>
                      </button>
                      <button
                        onClick={() => handleReceivePayment(project.id)}
                        className="px-4 py-2 bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 transition-colors flex items-center space-x-2"
                      >
                        <Check className="w-4 h-4" />
                        <span>Receber</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div className="flex space-x-4">
          <button
            onClick={() => setFilterType('all')}
            className={`px-4 py-2 rounded-xl transition-all duration-200 ${
              filterType === 'all'
                ? 'bg-white/20 text-white'
                : 'bg-white/10 text-white/70 hover:text-white hover:bg-white/15'
            }`}
          >
            Todas
          </button>
          <button
            onClick={() => setFilterType('income')}
            className={`px-4 py-2 rounded-xl transition-all duration-200 ${
              filterType === 'income'
                ? 'bg-green-500/20 text-green-400'
                : 'bg-white/10 text-white/70 hover:text-white hover:bg-white/15'
            }`}
          >
            Receitas
          </button>
          <button
            onClick={() => setFilterType('expense')}
            className={`px-4 py-2 rounded-xl transition-all duration-200 ${
              filterType === 'expense'
                ? 'bg-red-500/20 text-red-400'
                : 'bg-white/10 text-white/70 hover:text-white hover:bg-white/15'
            }`}
          >
            Despesas
          </button>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200 flex items-center space-x-2 shadow-lg hover:shadow-xl hover:scale-105"
        >
          <Plus className="w-5 h-5" />
          <span>Nova Transação</span>
        </button>
      </div>

      {/* Transaction Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 w-full max-w-md border border-white/20">
            <h3 className="text-xl font-semibold text-white mb-6">
              {editingTransaction ? 'Editar Transação' : 'Nova Transação'}
            </h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-white/70 text-sm font-medium mb-2">Tipo</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as Transaction['type'], category: '' })}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="income" className="bg-gray-800">Receita</option>
                  <option value="expense" className="bg-gray-800">Despesa</option>
                </select>
              </div>
              <div>
                <label className="block text-white/70 text-sm font-medium mb-2">Descrição</label>
                <input
                  type="text"
                  required
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Descrição da transação"
                />
              </div>
              <div>
                <label className="block text-white/70 text-sm font-medium mb-2">Valor (R$)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="0,00"
                />
              </div>
              <div>
                <label className="block text-white/70 text-sm font-medium mb-2">Categoria</label>
                <select
                  required
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="" className="bg-gray-800">Selecione uma categoria</option>
                  {categories[formData.type].map(category => (
                    <option key={category} value={category} className="bg-gray-800">{category}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-white/70 text-sm font-medium mb-2">Data</label>
                <input
                  type="date"
                  required
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              {formData.type === 'income' && (
                <div>
                  <label className="block text-white/70 text-sm font-medium mb-2">Projeto (opcional)</label>
                  <select
                    value={formData.projectId}
                    onChange={(e) => setFormData({ ...formData, projectId: e.target.value })}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="" className="bg-gray-800">Selecione um projeto</option>
                    {state.projects.map(project => (
                      <option key={project.id} value={project.id} className="bg-gray-800">{project.title}</option>
                    ))}
                  </select>
                </div>
              )}
              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-3 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200"
                >
                  {editingTransaction ? 'Salvar' : 'Criar'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Transactions List */}
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl border border-white/20 overflow-hidden">
        <div className="p-6 border-b border-white/20">
          <h3 className="text-xl font-semibold text-white">Transações Recentes</h3>
        </div>
        <div className="divide-y divide-white/10">
          {filteredTransactions.length === 0 ? (
            <div className="text-center py-12 text-white/50">
              <DollarSign className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Nenhuma transação encontrada</p>
            </div>
          ) : (
            filteredTransactions.map((transaction) => (
              <div
                key={transaction.id}
                className="p-6 hover:bg-white/5 transition-colors group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`p-3 rounded-xl ${
                      transaction.type === 'income' 
                        ? 'bg-green-500/20' 
                        : 'bg-red-500/20'
                    }`}>
                      {transaction.type === 'income' ? (
                        <TrendingUp className="w-5 h-5 text-green-400" />
                      ) : (
                        <TrendingDown className="w-5 h-5 text-red-400" />
                      )}
                    </div>
                    <div>
                      <h4 className="font-medium text-white">{transaction.description}</h4>
                      <div className="flex items-center space-x-2 text-sm text-white/60">
                        <span>{transaction.category}</span>
                        <span>•</span>
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-3 h-3" />
                          <span>{new Date(transaction.date).toLocaleDateString('pt-BR')}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className={`text-lg font-semibold ${
                      transaction.type === 'income' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {transaction.type === 'income' ? '+' : '-'}R$ {transaction.amount.toLocaleString('pt-BR')}
                    </span>
                    <div className="flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => handleEdit(transaction)}
                        className="p-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(transaction.id)}
                        className="p-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}