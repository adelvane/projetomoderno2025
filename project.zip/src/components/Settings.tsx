import React, { useState, useEffect } from 'react';
import { 
  Settings as SettingsIcon, 
  User, 
  Palette, 
  Bell, 
  Shield, 
  Upload, 
  X, 
  Save, 
  Eye, 
  EyeOff,
  RefreshCw,
  Download,
  Trash2,
  Check,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface SystemSettings {
  companyName: string;
  companyLogo: string;
  primaryColor: string;
  secondaryColor: string;
  theme: 'dark' | 'light';
  notifications: {
    email: boolean;
    push: boolean;
    projectDeadlines: boolean;
    paymentReminders: boolean;
  };
  currency: string;
  dateFormat: string;
  language: string;
  autoBackup: boolean;
  sessionTimeout: number;
}

export default function Settings() {
  const { authState } = useAuth();
  const [activeTab, setActiveTab] = useState('general');
  const [saving, setSaving] = useState(false);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [passwordData, setPasswordData] = useState({
    current: '',
    new: '',
    confirm: ''
  });

  const [settings, setSettings] = useState<SystemSettings>({
    companyName: 'DesignHub',
    companyLogo: '',
    primaryColor: '#3b82f6',
    secondaryColor: '#8b5cf6',
    theme: 'dark',
    notifications: {
      email: true,
      push: true,
      projectDeadlines: true,
      paymentReminders: true
    },
    currency: 'BRL',
    dateFormat: 'DD/MM/YYYY',
    language: 'pt-BR',
    autoBackup: true,
    sessionTimeout: 30
  });

  const [profileData, setProfileData] = useState({
    name: authState.user?.name || '',
    email: authState.user?.email || '',
    phone: '',
    company: '',
    bio: ''
  });

  // Carregar configurações salvas
  useEffect(() => {
    const savedSettings = localStorage.getItem('systemSettings');
    if (savedSettings) {
      setSettings({ ...settings, ...JSON.parse(savedSettings) });
    }

    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      setProfileData({ ...profileData, ...JSON.parse(savedProfile) });
    }

    // Carregar logo salvo
    const savedLogo = localStorage.getItem('companyLogo');
    if (savedLogo) {
      setLogoPreview(savedLogo);
      setSettings(prev => ({ ...prev, companyLogo: savedLogo }));
    }
  }, []);

  const tabs = [
    { id: 'general', name: 'Geral', icon: SettingsIcon },
    { id: 'profile', name: 'Perfil', icon: User },
    { id: 'appearance', name: 'Aparência', icon: Palette },
    { id: 'notifications', name: 'Notificações', icon: Bell },
    { id: 'security', name: 'Segurança', icon: Shield }
  ];

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
        alert('A imagem deve ter no máximo 2MB');
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setLogoPreview(result);
        setSettings(prev => ({ ...prev, companyLogo: result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveSettings = async () => {
    setSaving(true);
    try {
      // Salvar configurações no localStorage
      localStorage.setItem('systemSettings', JSON.stringify(settings));
      localStorage.setItem('userProfile', JSON.stringify(profileData));
      
      if (settings.companyLogo) {
        localStorage.setItem('companyLogo', settings.companyLogo);
      }

      // Aplicar mudanças de tema
      document.documentElement.style.setProperty('--primary-color', settings.primaryColor);
      document.documentElement.style.setProperty('--secondary-color', settings.secondaryColor);

      // Simular salvamento
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      alert('Configurações salvas com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar configurações:', error);
      alert('Erro ao salvar configurações. Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  const handlePasswordChange = async () => {
    if (passwordData.new !== passwordData.confirm) {
      alert('As senhas não coincidem');
      return;
    }

    if (passwordData.new.length < 6) {
      alert('A nova senha deve ter pelo menos 6 caracteres');
      return;
    }

    try {
      // Aqui você implementaria a mudança de senha via Supabase
      alert('Senha alterada com sucesso!');
      setPasswordData({ current: '', new: '', confirm: '' });
      setShowPasswordChange(false);
    } catch (error) {
      alert('Erro ao alterar senha. Tente novamente.');
    }
  };

  const exportSettings = () => {
    const dataToExport = {
      settings,
      profile: profileData,
      exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `configuracoes-designhub-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const resetSettings = () => {
    if (confirm('Tem certeza que deseja resetar todas as configurações? Esta ação não pode ser desfeita.')) {
      localStorage.removeItem('systemSettings');
      localStorage.removeItem('userProfile');
      localStorage.removeItem('companyLogo');
      window.location.reload();
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl">
            <SettingsIcon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Configurações do Sistema</h1>
            <p className="text-white/60">Personalize sua experiência no DesignHub</p>
          </div>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={exportSettings}
            className="px-4 py-2 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-colors flex items-center space-x-2"
          >
            <Download className="w-4 h-4" />
            <span>Exportar</span>
          </button>
          <button
            onClick={resetSettings}
            className="px-4 py-2 bg-red-500/20 text-red-400 rounded-xl hover:bg-red-500/30 transition-colors flex items-center space-x-2"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Resetar</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-4 border border-white/20">
            <nav className="space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-all duration-200 ${
                      activeTab === tab.id
                        ? 'bg-white/20 text-white shadow-lg'
                        : 'text-white/70 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{tab.name}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Content */}
        <div className="lg:col-span-3">
          <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
            {/* General Tab */}
            {activeTab === 'general' && (
              <div className="space-y-6">
                <h3 className="text-xl font-semibold text-white mb-6">Configurações Gerais</h3>
                
                {/* Company Logo */}
                <div>
                  <label className="block text-white/70 text-sm font-medium mb-3">Logo da Empresa</label>
                  <div className="flex items-center space-x-4">
                    {logoPreview ? (
                      <div className="relative">
                        <img 
                          src={logoPreview} 
                          alt="Logo preview" 
                          className="w-20 h-20 object-cover rounded-xl border border-white/20"
                        />
                        <button
                          onClick={() => {
                            setLogoPreview(null);
                            setSettings(prev => ({ ...prev, companyLogo: '' }));
                          }}
                          className="absolute -top-2 -right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <div className="w-20 h-20 bg-white/10 border-2 border-dashed border-white/30 rounded-xl flex items-center justify-center">
                        <Upload className="w-8 h-8 text-white/50" />
                      </div>
                    )}
                    <div className="flex-1">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleLogoUpload}
                        className="hidden"
                        id="logo-upload"
                      />
                      <label
                        htmlFor="logo-upload"
                        className="cursor-pointer px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors flex items-center space-x-2 w-fit"
                      >
                        <Upload className="w-4 h-4" />
                        <span>Escolher Logo</span>
                      </label>
                      <p className="text-white/50 text-xs mt-1">PNG, JPG até 2MB</p>
                    </div>
                  </div>
                </div>

                {/* Company Name */}
                <div>
                  <label className="block text-white/70 text-sm font-medium mb-2">Nome da Empresa</label>
                  <input
                    type="text"
                    value={settings.companyName}
                    onChange={(e) => setSettings(prev => ({ ...prev, companyName: e.target.value }))}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Nome da sua empresa"
                  />
                </div>

                {/* Currency */}
                <div>
                  <label className="block text-white/70 text-sm font-medium mb-2">Moeda</label>
                  <select
                    value={settings.currency}
                    onChange={(e) => setSettings(prev => ({ ...prev, currency: e.target.value }))}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="BRL" className="bg-gray-800">Real Brasileiro (R$)</option>
                    <option value="USD" className="bg-gray-800">Dólar Americano ($)</option>
                    <option value="EUR" className="bg-gray-800">Euro (€)</option>
                  </select>
                </div>

                {/* Date Format */}
                <div>
                  <label className="block text-white/70 text-sm font-medium mb-2">Formato de Data</label>
                  <select
                    value={settings.dateFormat}
                    onChange={(e) => setSettings(prev => ({ ...prev, dateFormat: e.target.value }))}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="DD/MM/YYYY" className="bg-gray-800">DD/MM/YYYY</option>
                    <option value="MM/DD/YYYY" className="bg-gray-800">MM/DD/YYYY</option>
                    <option value="YYYY-MM-DD" className="bg-gray-800">YYYY-MM-DD</option>
                  </select>
                </div>

                {/* Auto Backup */}
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-white font-medium">Backup Automático</label>
                    <p className="text-white/60 text-sm">Fazer backup dos dados automaticamente</p>
                  </div>
                  <button
                    onClick={() => setSettings(prev => ({ ...prev, autoBackup: !prev.autoBackup }))}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      settings.autoBackup ? 'bg-blue-500' : 'bg-white/20'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        settings.autoBackup ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              </div>
            )}

            {/* Profile Tab */}
            {activeTab === 'profile' && (
              <div className="space-y-6">
                <h3 className="text-xl font-semibold text-white mb-6">Perfil do Usuário</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-white/70 text-sm font-medium mb-2">Nome</label>
                    <input
                      type="text"
                      value={profileData.name}
                      onChange={(e) => setProfileData(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-white/70 text-sm font-medium mb-2">Email</label>
                    <input
                      type="email"
                      value={profileData.email}
                      onChange={(e) => setProfileData(prev => ({ ...prev, email: e.target.value }))}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-white/70 text-sm font-medium mb-2">Telefone</label>
                    <input
                      type="tel"
                      value={profileData.phone}
                      onChange={(e) => setProfileData(prev => ({ ...prev, phone: e.target.value }))}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="(11) 99999-9999"
                    />
                  </div>
                  <div>
                    <label className="block text-white/70 text-sm font-medium mb-2">Empresa</label>
                    <input
                      type="text"
                      value={profileData.company}
                      onChange={(e) => setProfileData(prev => ({ ...prev, company: e.target.value }))}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-white/70 text-sm font-medium mb-2">Bio</label>
                  <textarea
                    value={profileData.bio}
                    onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                    rows={3}
                    placeholder="Conte um pouco sobre você..."
                  />
                </div>
              </div>
            )}

            {/* Appearance Tab */}
            {activeTab === 'appearance' && (
              <div className="space-y-6">
                <h3 className="text-xl font-semibold text-white mb-6">Aparência</h3>
                
                {/* Primary Color */}
                <div>
                  <label className="block text-white/70 text-sm font-medium mb-2">Cor Primária</label>
                  <div className="flex items-center space-x-3">
                    <input
                      type="color"
                      value={settings.primaryColor}
                      onChange={(e) => setSettings(prev => ({ ...prev, primaryColor: e.target.value }))}
                      className="w-12 h-12 rounded-lg border border-white/20 bg-transparent cursor-pointer"
                    />
                    <input
                      type="text"
                      value={settings.primaryColor}
                      onChange={(e) => setSettings(prev => ({ ...prev, primaryColor: e.target.value }))}
                      className="flex-1 px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* Secondary Color */}
                <div>
                  <label className="block text-white/70 text-sm font-medium mb-2">Cor Secundária</label>
                  <div className="flex items-center space-x-3">
                    <input
                      type="color"
                      value={settings.secondaryColor}
                      onChange={(e) => setSettings(prev => ({ ...prev, secondaryColor: e.target.value }))}
                      className="w-12 h-12 rounded-lg border border-white/20 bg-transparent cursor-pointer"
                    />
                    <input
                      type="text"
                      value={settings.secondaryColor}
                      onChange={(e) => setSettings(prev => ({ ...prev, secondaryColor: e.target.value }))}
                      className="flex-1 px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* Theme Preview */}
                <div>
                  <label className="block text-white/70 text-sm font-medium mb-3">Prévia do Tema</label>
                  <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                    <div className="flex items-center space-x-3 mb-3">
                      <div 
                        className="w-8 h-8 rounded-lg"
                        style={{ backgroundColor: settings.primaryColor }}
                      />
                      <div 
                        className="w-8 h-8 rounded-lg"
                        style={{ backgroundColor: settings.secondaryColor }}
                      />
                      <span className="text-white text-sm">Cores do sistema</span>
                    </div>
                    <div 
                      className="px-4 py-2 rounded-lg text-white text-sm"
                      style={{ 
                        background: `linear-gradient(to right, ${settings.primaryColor}, ${settings.secondaryColor})` 
                      }}
                    >
                      Exemplo de botão com gradiente
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Notifications Tab */}
            {activeTab === 'notifications' && (
              <div className="space-y-6">
                <h3 className="text-xl font-semibold text-white mb-6">Notificações</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-white font-medium">Notificações por Email</label>
                      <p className="text-white/60 text-sm">Receber notificações por email</p>
                    </div>
                    <button
                      onClick={() => setSettings(prev => ({ 
                        ...prev, 
                        notifications: { ...prev.notifications, email: !prev.notifications.email }
                      }))}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.notifications.email ? 'bg-blue-500' : 'bg-white/20'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.notifications.email ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-white font-medium">Notificações Push</label>
                      <p className="text-white/60 text-sm">Receber notificações no navegador</p>
                    </div>
                    <button
                      onClick={() => setSettings(prev => ({ 
                        ...prev, 
                        notifications: { ...prev.notifications, push: !prev.notifications.push }
                      }))}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.notifications.push ? 'bg-blue-500' : 'bg-white/20'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.notifications.push ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-white font-medium">Prazos de Projetos</label>
                      <p className="text-white/60 text-sm">Alertas sobre prazos próximos</p>
                    </div>
                    <button
                      onClick={() => setSettings(prev => ({ 
                        ...prev, 
                        notifications: { ...prev.notifications, projectDeadlines: !prev.notifications.projectDeadlines }
                      }))}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.notifications.projectDeadlines ? 'bg-blue-500' : 'bg-white/20'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.notifications.projectDeadlines ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-white font-medium">Lembretes de Pagamento</label>
                      <p className="text-white/60 text-sm">Alertas sobre pagamentos pendentes</p>
                    </div>
                    <button
                      onClick={() => setSettings(prev => ({ 
                        ...prev, 
                        notifications: { ...prev.notifications, paymentReminders: !prev.notifications.paymentReminders }
                      }))}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.notifications.paymentReminders ? 'bg-blue-500' : 'bg-white/20'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.notifications.paymentReminders ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Security Tab */}
            {activeTab === 'security' && (
              <div className="space-y-6">
                <h3 className="text-xl font-semibold text-white mb-6">Segurança</h3>
                
                {/* Change Password */}
                <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="text-white font-medium">Alterar Senha</h4>
                      <p className="text-white/60 text-sm">Mantenha sua conta segura</p>
                    </div>
                    <button
                      onClick={() => setShowPasswordChange(!showPasswordChange)}
                      className="px-4 py-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-colors"
                    >
                      {showPasswordChange ? 'Cancelar' : 'Alterar'}
                    </button>
                  </div>

                  {showPasswordChange && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-white/70 text-sm font-medium mb-2">Senha Atual</label>
                        <input
                          type="password"
                          value={passwordData.current}
                          onChange={(e) => setPasswordData(prev => ({ ...prev, current: e.target.value }))}
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-white/70 text-sm font-medium mb-2">Nova Senha</label>
                        <input
                          type="password"
                          value={passwordData.new}
                          onChange={(e) => setPasswordData(prev => ({ ...prev, new: e.target.value }))}
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-white/70 text-sm font-medium mb-2">Confirmar Nova Senha</label>
                        <input
                          type="password"
                          value={passwordData.confirm}
                          onChange={(e) => setPasswordData(prev => ({ ...prev, confirm: e.target.value }))}
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <button
                        onClick={handlePasswordChange}
                        className="px-4 py-2 bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 transition-colors"
                      >
                        Confirmar Alteração
                      </button>
                    </div>
                  )}
                </div>

                {/* Session Timeout */}
                <div>
                  <label className="block text-white/70 text-sm font-medium mb-2">Timeout da Sessão (minutos)</label>
                  <select
                    value={settings.sessionTimeout}
                    onChange={(e) => setSettings(prev => ({ ...prev, sessionTimeout: parseInt(e.target.value) }))}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value={15} className="bg-gray-800">15 minutos</option>
                    <option value={30} className="bg-gray-800">30 minutos</option>
                    <option value={60} className="bg-gray-800">1 hora</option>
                    <option value={120} className="bg-gray-800">2 horas</option>
                    <option value={0} className="bg-gray-800">Nunca</option>
                  </select>
                </div>

                {/* Security Info */}
                <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4">
                  <div className="flex items-start space-x-3">
                    <AlertCircle className="w-5 h-5 text-blue-400 mt-0.5" />
                    <div>
                      <h4 className="text-blue-400 font-medium mb-1">Dicas de Segurança</h4>
                      <ul className="text-blue-400/80 text-sm space-y-1">
                        <li>• Use uma senha forte com pelo menos 8 caracteres</li>
                        <li>• Não compartilhe suas credenciais de acesso</li>
                        <li>• Faça logout ao usar computadores públicos</li>
                        <li>• Mantenha o sistema sempre atualizado</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Save Button */}
            <div className="flex justify-end pt-6 border-t border-white/10">
              <button
                onClick={handleSaveSettings}
                disabled={saving}
                className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200 flex items-center space-x-2 disabled:opacity-50"
              >
                {saving ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Save className="w-5 h-5" />
                )}
                <span>{saving ? 'Salvando...' : 'Salvar Configurações'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}