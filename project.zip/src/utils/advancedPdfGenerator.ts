import jsPDF from 'jspdf';
import 'jspdf-autotable';

// Extend jsPDF type to include autoTable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

interface AdvancedReportData {
  period: string;
  startDate: Date;
  endDate: Date;
  totalIncome: number;
  totalExpenses: number;
  profit: number;
  incomeGrowth: number;
  incomeByCategory: Record<string, number>;
  expensesByCategory: Record<string, number>;
  projectsByStatus: Record<string, number>;
  projectsByPriority: Record<string, number>;
  clientsData: Record<string, any>;
  dailyRevenue: Record<number, number>;
  activeClients: number;
  totalProjects: number;
  avgProjectValue: number;
  completionRate: number;
  transactions: any[];
  projects: any[];
}

export const generateAdvancedReport = async (data: AdvancedReportData, reportType: string) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;
  const pageHeight = doc.internal.pageSize.height;
  let yPosition = 20;

  // Color palette
  const colors = {
    primary: [52, 73, 94],
    success: [39, 174, 96],
    danger: [231, 76, 60],
    warning: [241, 196, 15],
    info: [52, 152, 219],
    purple: [155, 89, 182],
    dark: [44, 62, 80],
    light: [189, 195, 199]
  };

  // Helper functions
  const checkPageBreak = (requiredSpace: number) => {
    if (yPosition + requiredSpace > pageHeight - 30) {
      doc.addPage();
      yPosition = 20;
      addHeader();
      return true;
    }
    return false;
  };

  const formatCurrency = (amount: number) => {
    return `R$ ${amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
  };

  const addHeader = () => {
    // Header background
    doc.setFillColor(52, 73, 94);
    doc.rect(0, 0, pageWidth, 25, 'F');
    
    doc.setFontSize(16);
    doc.setTextColor(255, 255, 255);
    doc.text('DesignHub - Relatório Avançado', 20, 15);
    
    doc.setFontSize(10);
    doc.text(data.period, pageWidth - 20, 15, { align: 'right' });
    
    yPosition = 35;
  };

  const addFooter = () => {
    const pageNumber = doc.getNumberOfPages();
    doc.setFontSize(8);
    doc.setTextColor(127, 140, 141);
    doc.text(`Página ${pageNumber}`, pageWidth / 2, pageHeight - 10, { align: 'center' });
    doc.text(`Gerado em ${new Date().toLocaleDateString('pt-BR')}`, pageWidth - 20, pageHeight - 10, { align: 'right' });
  };

  const addSection = (title: string, color: number[] = colors.primary) => {
    checkPageBreak(20);
    
    // Section header with background
    doc.setFillColor(color[0], color[1], color[2]);
    doc.rect(20, yPosition - 5, pageWidth - 40, 15, 'F');
    
    doc.setFontSize(14);
    doc.setTextColor(255, 255, 255);
    doc.text(title, 25, yPosition + 5);
    
    yPosition += 20;
  };

  const createChart = (x: number, y: number, width: number, height: number, data: Record<string, number>, title: string, color: number[]) => {
    // Chart background
    doc.setFillColor(248, 249, 250);
    doc.rect(x, y, width, height, 'F');
    doc.setDrawColor(189, 195, 199);
    doc.rect(x, y, width, height);
    
    // Title
    doc.setFontSize(10);
    doc.setTextColor(44, 62, 80);
    doc.text(title, x + width/2, y + 10, { align: 'center' });
    
    // Simple bar chart
    const entries = Object.entries(data).slice(0, 5); // Top 5
    const maxValue = Math.max(...entries.map(([, value]) => value));
    const barHeight = 8;
    const startY = y + 20;
    
    entries.forEach(([label, value], index) => {
      const barWidth = maxValue > 0 ? (value / maxValue) * (width - 60) : 0;
      const barY = startY + (index * (barHeight + 5));
      
      // Bar
      doc.setFillColor(color[0], color[1], color[2]);
      doc.rect(x + 50, barY, barWidth, barHeight, 'F');
      
      // Label
      doc.setFontSize(8);
      doc.setTextColor(44, 62, 80);
      doc.text(label.substring(0, 8), x + 5, barY + 5);
      
      // Value
      doc.text(formatCurrency(value), x + width - 5, barY + 5, { align: 'right' });
    });
  };

  // Start generating report
  addHeader();

  // Executive Summary
  addSection('RESUMO EXECUTIVO', colors.primary);
  
  const summaryData = [
    ['Período de Análise', data.period],
    ['Receita Total', formatCurrency(data.totalIncome)],
    ['Despesas Totais', formatCurrency(data.totalExpenses)],
    ['Lucro Líquido', formatCurrency(data.profit)],
    ['Margem de Lucro', `${data.totalIncome > 0 ? ((data.profit / data.totalIncome) * 100).toFixed(1) : '0'}%`],
    ['Crescimento vs Mês Anterior', `${data.incomeGrowth > 0 ? '+' : ''}${data.incomeGrowth.toFixed(1)}%`],
    ['Total de Projetos', data.totalProjects.toString()],
    ['Taxa de Conclusão', `${data.completionRate.toFixed(1)}%`],
    ['Clientes Ativos', data.activeClients.toString()],
    ['Valor Médio por Projeto', formatCurrency(data.avgProjectValue)]
  ];

  doc.autoTable({
    startY: yPosition,
    body: summaryData,
    theme: 'grid',
    styles: { 
      fontSize: 10,
      cellPadding: 3
    },
    columnStyles: {
      0: { fontStyle: 'bold', fillColor: [248, 249, 250] },
      1: { halign: 'right' }
    },
    margin: { left: 20, right: 20 }
  });

  yPosition = (doc as any).lastAutoTable.finalY + 20;

  // Financial Analysis (for complete and financial reports)
  if (reportType === 'complete' || reportType === 'financial') {
    addSection('ANÁLISE FINANCEIRA DETALHADA', colors.success);
    
    // Income vs Expenses comparison
    const financialComparison = [
      ['Indicador', 'Valor', '% do Total', 'Status'],
      ['Receitas', formatCurrency(data.totalIncome), '100%', data.incomeGrowth > 0 ? '↗ Crescimento' : data.incomeGrowth < 0 ? '↘ Declínio' : '→ Estável'],
      ['Despesas', formatCurrency(data.totalExpenses), `${data.totalIncome > 0 ? ((data.totalExpenses / data.totalIncome) * 100).toFixed(1) : '0'}%`, data.totalExpenses < data.totalIncome * 0.7 ? '✓ Controladas' : '⚠ Atenção'],
      ['Lucro/Prejuízo', formatCurrency(data.profit), `${data.totalIncome > 0 ? ((data.profit / data.totalIncome) * 100).toFixed(1) : '0'}%`, data.profit > 0 ? '✓ Lucrativo' : '✗ Prejuízo']
    ];

    doc.autoTable({
      startY: yPosition,
      head: [financialComparison[0]],
      body: financialComparison.slice(1),
      theme: 'striped',
      headStyles: { fillColor: colors.success, textColor: 255 },
      styles: { fontSize: 9 },
      margin: { left: 20, right: 20 }
    });

    yPosition = (doc as any).lastAutoTable.finalY + 15;

    // Charts side by side
    if (Object.keys(data.incomeByCategory).length > 0) {
      checkPageBreak(80);
      createChart(20, yPosition, 80, 70, data.incomeByCategory, 'Receitas por Categoria', colors.success);
    }
    
    if (Object.keys(data.expensesByCategory).length > 0) {
      createChart(110, yPosition, 80, 70, data.expensesByCategory, 'Despesas por Categoria', colors.danger);
    }
    
    yPosition += 80;
  }

  // Project Analysis (for complete and projects reports)
  if (reportType === 'complete' || reportType === 'projects') {
    addSection('ANÁLISE DE PROJETOS', colors.info);
    
    // Project status breakdown
    const getStatusText = (status: string) => {
      const statusMap: Record<string, string> = {
        'pending': 'Pendente',
        'in-progress': 'Em Andamento',
        'completed': 'Finalizado',
        'cancelled': 'Cancelado'
      };
      return statusMap[status] || status;
    };

    const projectStatusData = Object.entries(data.projectsByStatus).map(([status, count]) => [
      getStatusText(status),
      count.toString(),
      `${((count as number / data.totalProjects) * 100).toFixed(1)}%`
    ]);

    if (projectStatusData.length > 0) {
      doc.autoTable({
        startY: yPosition,
        head: [['Status', 'Quantidade', '% do Total']],
        body: projectStatusData,
        theme: 'grid',
        headStyles: { fillColor: colors.info, textColor: 255 },
        styles: { fontSize: 10 },
        margin: { left: 20, right: pageWidth/2 }
      });
    }

    // Project priority breakdown
    const getPriorityText = (priority: string) => {
      const priorityMap: Record<string, string> = {
        'high': 'Alta',
        'medium': 'Média',
        'low': 'Baixa'
      };
      return priorityMap[priority] || priority;
    };

    const projectPriorityData = Object.entries(data.projectsByPriority).map(([priority, count]) => [
      getPriorityText(priority),
      count.toString(),
      `${((count as number / data.totalProjects) * 100).toFixed(1)}%`
    ]);

    if (projectPriorityData.length > 0) {
      doc.autoTable({
        startY: yPosition,
        head: [['Prioridade', 'Quantidade', '% do Total']],
        body: projectPriorityData,
        theme: 'grid',
        headStyles: { fillColor: colors.warning, textColor: 255 },
        styles: { fontSize: 10 },
        margin: { left: pageWidth/2 + 10, right: 20 }
      });
    }

    yPosition = Math.max((doc as any).lastAutoTable.finalY, yPosition) + 20;

    // Project performance metrics
    checkPageBreak(40);
    const performanceMetrics = [
      ['Métrica', 'Valor', 'Benchmark'],
      ['Taxa de Conclusão', `${data.completionRate.toFixed(1)}%`, '≥ 80%'],
      ['Valor Médio por Projeto', formatCurrency(data.avgProjectValue), 'Variável'],
      ['Projetos por Cliente', `${(data.totalProjects / Math.max(data.activeClients, 1)).toFixed(1)}`, '≥ 2'],
      ['Receita por Projeto', formatCurrency(data.totalProjects > 0 ? data.totalIncome / data.totalProjects : 0), 'Crescente']
    ];

    doc.autoTable({
      startY: yPosition,
      head: [performanceMetrics[0]],
      body: performanceMetrics.slice(1),
      theme: 'striped',
      headStyles: { fillColor: colors.purple, textColor: 255 },
      styles: { fontSize: 10 },
      margin: { left: 20, right: 20 }
    });

    yPosition = (doc as any).lastAutoTable.finalY + 20;
  }

  // Client Analysis (for complete and clients reports)
  if (reportType === 'complete' || reportType === 'clients') {
    addSection('ANÁLISE DE CLIENTES', colors.purple);
    
    if (Object.keys(data.clientsData).length > 0) {
      const clientAnalysisData = Object.entries(data.clientsData)
        .sort(([,a], [,b]) => (b as any).revenue - (a as any).revenue)
        .slice(0, 10) // Top 10 clients
        .map(([, clientData]) => [
          (clientData as any).name,
          (clientData as any).projects.toString(),
          formatCurrency((clientData as any).revenue),
          formatCurrency((clientData as any).revenue / (clientData as any).projects)
        ]);

      doc.autoTable({
        startY: yPosition,
        head: [['Cliente', 'Projetos', 'Receita Total', 'Receita/Projeto']],
        body: clientAnalysisData,
        theme: 'striped',
        headStyles: { fillColor: colors.purple, textColor: 255 },
        styles: { fontSize: 9 },
        margin: { left: 20, right: 20 }
      });

      yPosition = (doc as any).lastAutoTable.finalY + 20;
    } else {
      doc.setFontSize(10);
      doc.setTextColor(127, 140, 141);
      doc.text('Nenhum cliente ativo no período analisado.', 20, yPosition);
      yPosition += 20;
    }
  }

  // Detailed Transactions (for complete reports)
  if (reportType === 'complete' && data.transactions.length > 0) {
    checkPageBreak(30);
    addSection('TRANSAÇÕES DETALHADAS', colors.dark);
    
    const transactionData = data.transactions
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 15) // Last 15 transactions
      .map(transaction => [
        new Date(transaction.date).toLocaleDateString('pt-BR'),
        transaction.description.substring(0, 25) + (transaction.description.length > 25 ? '...' : ''),
        transaction.category,
        transaction.type === 'income' ? 'Receita' : 'Despesa',
        formatCurrency(transaction.amount)
      ]);

    doc.autoTable({
      startY: yPosition,
      head: [['Data', 'Descrição', 'Categoria', 'Tipo', 'Valor']],
      body: transactionData,
      theme: 'grid',
      headStyles: { fillColor: colors.dark, textColor: 255 },
      styles: { fontSize: 8 },
      columnStyles: {
        0: { cellWidth: 25 },
        1: { cellWidth: 45 },
        2: { cellWidth: 30 },
        3: { cellWidth: 25 },
        4: { cellWidth: 30, halign: 'right' }
      },
      margin: { left: 20, right: 20 }
    });

    yPosition = (doc as any).lastAutoTable.finalY + 20;
  }

  // Insights and Recommendations
  checkPageBreak(50);
  addSection('INSIGHTS E RECOMENDAÇÕES', colors.warning);
  
  const insights = [];
  
  // Financial insights
  if (data.profit > 0) {
    insights.push(`✓ Período lucrativo com margem de ${((data.profit / data.totalIncome) * 100).toFixed(1)}%`);
    if (data.profit / data.totalIncome > 0.3) {
      insights.push(`✓ Excelente margem de lucro, superior a 30%`);
    }
  } else {
    insights.push(`⚠ Período com prejuízo de ${formatCurrency(Math.abs(data.profit))}`);
    insights.push(`→ Recomendação: Revisar estrutura de custos e estratégia de precificação`);
  }

  // Growth insights
  if (data.incomeGrowth > 10) {
    insights.push(`✓ Crescimento excepcional de ${data.incomeGrowth.toFixed(1)}% vs mês anterior`);
  } else if (data.incomeGrowth > 0) {
    insights.push(`✓ Crescimento positivo de ${data.incomeGrowth.toFixed(1)}% vs mês anterior`);
  } else if (data.incomeGrowth < -10) {
    insights.push(`⚠ Declínio significativo de ${Math.abs(data.incomeGrowth).toFixed(1)}% vs mês anterior`);
    insights.push(`→ Recomendação: Investigar causas e implementar ações corretivas`);
  }

  // Project insights
  if (data.completionRate > 80) {
    insights.push(`✓ Excelente taxa de conclusão de projetos: ${data.completionRate.toFixed(1)}%`);
  } else if (data.completionRate < 60) {
    insights.push(`⚠ Taxa de conclusão baixa: ${data.completionRate.toFixed(1)}%`);
    insights.push(`→ Recomendação: Revisar processos de gestão de projetos`);
  }

  // Client insights
  if (data.activeClients > 0) {
    const projectsPerClient = data.totalProjects / data.activeClients;
    if (projectsPerClient < 1.5) {
      insights.push(`→ Oportunidade: Desenvolver relacionamentos mais profundos com clientes existentes`);
    }
  }

  // Revenue concentration
  const topIncomeCategory = Object.entries(data.incomeByCategory)
    .sort(([,a], [,b]) => b - a)[0];
  if (topIncomeCategory && topIncomeCategory[1] / data.totalIncome > 0.7) {
    insights.push(`⚠ Alta concentração de receita em ${topIncomeCategory[0]} (${((topIncomeCategory[1] / data.totalIncome) * 100).toFixed(1)}%)`);
    insights.push(`→ Recomendação: Diversificar fontes de receita`);
  }

  doc.setFontSize(9);
  doc.setTextColor(44, 62, 80);
  
  insights.forEach((insight, index) => {
    checkPageBreak(8);
    const bullet = insight.startsWith('✓') ? '✓' : insight.startsWith('⚠') ? '⚠' : insight.startsWith('→') ? '→' : '•';
    const color = insight.startsWith('✓') ? colors.success : insight.startsWith('⚠') ? colors.danger : insight.startsWith('→') ? colors.info : colors.dark;
    
    doc.setTextColor(color[0], color[1], color[2]);
    doc.text(bullet, 25, yPosition);
    
    doc.setTextColor(44, 62, 80);
    doc.text(insight.substring(2), 30, yPosition);
    yPosition += 6;
  });

  // Add footer to all pages
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    addFooter();
  }

  // Save the PDF
  const reportTypeNames = {
    complete: 'completo',
    financial: 'financeiro',
    projects: 'projetos',
    clients: 'clientes'
  };
  
  const fileName = `relatorio-${reportTypeNames[reportType as keyof typeof reportTypeNames]}-${data.period.toLowerCase().replace(' ', '-')}.pdf`;
  doc.save(fileName);
};