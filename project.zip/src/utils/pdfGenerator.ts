import jsPDF from 'jspdf';
import 'jspdf-autotable';

// Extend jsPDF type to include autoTable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

interface ReportData {
  period: string;
  startDate: Date;
  endDate: Date;
  totalIncome: number;
  totalExpenses: number;
  profit: number;
  incomeByCategory: Record<string, number>;
  expensesByCategory: Record<string, number>;
  projectsByStatus: Record<string, number>;
  activeClients: number;
  totalProjects: number;
  transactions: any[];
  projects: any[];
}

export const generateMonthlyReport = async (data: ReportData) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;
  const pageHeight = doc.internal.pageSize.height;
  let yPosition = 20;

  // Helper function to add new page if needed
  const checkPageBreak = (requiredSpace: number) => {
    if (yPosition + requiredSpace > pageHeight - 20) {
      doc.addPage();
      yPosition = 20;
      return true;
    }
    return false;
  };

  // Helper function to format currency
  const formatCurrency = (amount: number) => {
    return `R$ ${amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
  };

  // Header
  doc.setFontSize(24);
  doc.setTextColor(44, 62, 80);
  doc.text('RELATÓRIO MENSAL', pageWidth / 2, yPosition, { align: 'center' });
  yPosition += 10;

  doc.setFontSize(16);
  doc.setTextColor(127, 140, 141);
  doc.text(`Período: ${data.period}`, pageWidth / 2, yPosition, { align: 'center' });
  yPosition += 5;

  doc.setFontSize(12);
  doc.text(`Gerado em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}`, pageWidth / 2, yPosition, { align: 'center' });
  yPosition += 20;

  // Line separator
  doc.setDrawColor(189, 195, 199);
  doc.line(20, yPosition, pageWidth - 20, yPosition);
  yPosition += 15;

  // Financial Summary
  doc.setFontSize(18);
  doc.setTextColor(44, 62, 80);
  doc.text('RESUMO FINANCEIRO', 20, yPosition);
  yPosition += 15;

  // Financial summary table
  const financialData = [
    ['Receitas Totais', formatCurrency(data.totalIncome)],
    ['Despesas Totais', formatCurrency(data.totalExpenses)],
    ['Lucro/Prejuízo', formatCurrency(data.profit)],
    ['Margem de Lucro', `${data.totalIncome > 0 ? ((data.profit / data.totalIncome) * 100).toFixed(1) : '0'}%`]
  ];

  doc.autoTable({
    startY: yPosition,
    head: [['Indicador', 'Valor']],
    body: financialData,
    theme: 'grid',
    headStyles: { fillColor: [52, 73, 94], textColor: 255 },
    styles: { fontSize: 11 },
    margin: { left: 20, right: 20 }
  });

  yPosition = (doc as any).lastAutoTable.finalY + 20;
  checkPageBreak(30);

  // Income by Category
  if (Object.keys(data.incomeByCategory).length > 0) {
    doc.setFontSize(16);
    doc.setTextColor(44, 62, 80);
    doc.text('RECEITAS POR CATEGORIA', 20, yPosition);
    yPosition += 10;

    const incomeData = Object.entries(data.incomeByCategory).map(([category, amount]) => [
      category,
      formatCurrency(amount),
      `${((amount / data.totalIncome) * 100).toFixed(1)}%`
    ]);

    doc.autoTable({
      startY: yPosition,
      head: [['Categoria', 'Valor', '% do Total']],
      body: incomeData,
      theme: 'striped',
      headStyles: { fillColor: [39, 174, 96], textColor: 255 },
      styles: { fontSize: 10 },
      margin: { left: 20, right: 20 }
    });

    yPosition = (doc as any).lastAutoTable.finalY + 20;
    checkPageBreak(30);
  }

  // Expenses by Category
  if (Object.keys(data.expensesByCategory).length > 0) {
    doc.setFontSize(16);
    doc.setTextColor(44, 62, 80);
    doc.text('DESPESAS POR CATEGORIA', 20, yPosition);
    yPosition += 10;

    const expenseData = Object.entries(data.expensesByCategory).map(([category, amount]) => [
      category,
      formatCurrency(amount),
      `${((amount / data.totalExpenses) * 100).toFixed(1)}%`
    ]);

    doc.autoTable({
      startY: yPosition,
      head: [['Categoria', 'Valor', '% do Total']],
      body: expenseData,
      theme: 'striped',
      headStyles: { fillColor: [231, 76, 60], textColor: 255 },
      styles: { fontSize: 10 },
      margin: { left: 20, right: 20 }
    });

    yPosition = (doc as any).lastAutoTable.finalY + 20;
    checkPageBreak(30);
  }

  // Projects Summary
  doc.setFontSize(16);
  doc.setTextColor(44, 62, 80);
  doc.text('RESUMO DE PROJETOS', 20, yPosition);
  yPosition += 10;

  const getStatusText = (status: string) => {
    const statusMap: Record<string, string> = {
      'pending': 'Pendente',
      'in-progress': 'Em Andamento',
      'completed': 'Finalizado',
      'cancelled': 'Cancelado'
    };
    return statusMap[status] || status;
  };

  const projectSummaryData = [
    ['Total de Projetos', data.totalProjects.toString()],
    ['Clientes Ativos', data.activeClients.toString()],
    ...Object.entries(data.projectsByStatus).map(([status, count]) => [
      getStatusText(status),
      count.toString()
    ])
  ];

  doc.autoTable({
    startY: yPosition,
    head: [['Métrica', 'Quantidade']],
    body: projectSummaryData,
    theme: 'grid',
    headStyles: { fillColor: [155, 89, 182], textColor: 255 },
    styles: { fontSize: 11 },
    margin: { left: 20, right: 20 }
  });

  yPosition = (doc as any).lastAutoTable.finalY + 20;
  checkPageBreak(50);

  // Detailed Transactions
  if (data.transactions.length > 0) {
    doc.setFontSize(16);
    doc.setTextColor(44, 62, 80);
    doc.text('TRANSAÇÕES DETALHADAS', 20, yPosition);
    yPosition += 10;

    const transactionData = data.transactions
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 20) // Limit to 20 most recent transactions
      .map(transaction => [
        new Date(transaction.date).toLocaleDateString('pt-BR'),
        transaction.description.substring(0, 30) + (transaction.description.length > 30 ? '...' : ''),
        transaction.category,
        transaction.type === 'income' ? 'Receita' : 'Despesa',
        formatCurrency(transaction.amount)
      ]);

    doc.autoTable({
      startY: yPosition,
      head: [['Data', 'Descrição', 'Categoria', 'Tipo', 'Valor']],
      body: transactionData,
      theme: 'striped',
      headStyles: { fillColor: [52, 152, 219], textColor: 255 },
      styles: { fontSize: 9 },
      columnStyles: {
        0: { cellWidth: 25 },
        1: { cellWidth: 50 },
        2: { cellWidth: 30 },
        3: { cellWidth: 25 },
        4: { cellWidth: 30 }
      },
      margin: { left: 20, right: 20 }
    });

    yPosition = (doc as any).lastAutoTable.finalY + 20;
  }

  // Footer with analysis
  checkPageBreak(40);
  doc.setFontSize(14);
  doc.setTextColor(44, 62, 80);
  doc.text('ANÁLISE E INSIGHTS', 20, yPosition);
  yPosition += 10;

  doc.setFontSize(10);
  doc.setTextColor(127, 140, 141);

  const insights = [];
  
  if (data.profit > 0) {
    insights.push(`✓ Período lucrativo com margem de ${((data.profit / data.totalIncome) * 100).toFixed(1)}%`);
  } else {
    insights.push(`⚠ Período com prejuízo de ${formatCurrency(Math.abs(data.profit))}`);
  }

  if (data.totalProjects > 0) {
    insights.push(`✓ ${data.totalProjects} projetos gerenciados com ${data.activeClients} clientes ativos`);
  }

  const topIncomeCategory = Object.entries(data.incomeByCategory)
    .sort(([,a], [,b]) => b - a)[0];
  if (topIncomeCategory) {
    insights.push(`✓ Maior fonte de receita: ${topIncomeCategory[0]} (${formatCurrency(topIncomeCategory[1])})`);
  }

  const topExpenseCategory = Object.entries(data.expensesByCategory)
    .sort(([,a], [,b]) => b - a)[0];
  if (topExpenseCategory) {
    insights.push(`⚠ Maior categoria de despesa: ${topExpenseCategory[0]} (${formatCurrency(topExpenseCategory[1])})`);
  }

  insights.forEach(insight => {
    doc.text(`• ${insight}`, 25, yPosition);
    yPosition += 6;
  });

  // Footer
  yPosition = pageHeight - 30;
  doc.setFontSize(8);
  doc.setTextColor(149, 165, 166);
  doc.text('DesignHub - Sistema de Gestão de Projetos', pageWidth / 2, yPosition, { align: 'center' });
  doc.text(`Página 1 de ${doc.getNumberOfPages()}`, pageWidth - 20, yPosition, { align: 'right' });

  // Save the PDF
  const fileName = `relatorio-mensal-${data.period.toLowerCase().replace(' ', '-')}.pdf`;
  doc.save(fileName);
};