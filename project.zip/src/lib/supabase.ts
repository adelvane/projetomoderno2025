import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Database {
  public: {
    Tables: {
      clients: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          email: string;
          phone: string;
          company: string | null;
          address: string;
          cnpj: string;
          logo_url: string | null;
          total_projects: number;
          total_revenue: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          email: string;
          phone: string;
          company?: string | null;
          address: string;
          cnpj: string;
          logo_url?: string | null;
          total_projects?: number;
          total_revenue?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          name?: string;
          email?: string;
          phone?: string;
          company?: string | null;
          address?: string;
          cnpj?: string;
          logo_url?: string | null;
          total_projects?: number;
          total_revenue?: number;
          created_at?: string;
        };
      };
      projects: {
        Row: {
          id: string;
          user_id: string;
          client_id: string;
          client_name: string;
          title: string;
          description: string;
          status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
          priority: 'low' | 'medium' | 'high';
          value: number;
          deadline: string;
          created_at: string;
          completed_at: string | null;
          payment_received: boolean;
          payment_date: string | null;
        };
        Insert: {
          id?: string;
          user_id: string;
          client_id: string;
          client_name: string;
          title: string;
          description: string;
          status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
          priority: 'low' | 'medium' | 'high';
          value: number;
          deadline: string;
          created_at?: string;
          completed_at?: string | null;
          payment_received?: boolean;
          payment_date?: string | null;
        };
        Update: {
          id?: string;
          user_id?: string;
          client_id?: string;
          client_name?: string;
          title?: string;
          description?: string;
          status?: 'pending' | 'in-progress' | 'completed' | 'cancelled';
          priority?: 'low' | 'medium' | 'high';
          value?: number;
          deadline?: string;
          created_at?: string;
          completed_at?: string | null;
          payment_received?: boolean;
          payment_date?: string | null;
        };
      };
      transactions: {
        Row: {
          id: string;
          user_id: string;
          type: 'income' | 'expense';
          description: string;
          amount: number;
          category: string;
          date: string;
          project_id: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          type: 'income' | 'expense';
          description: string;
          amount: number;
          category: string;
          date: string;
          project_id?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          type?: 'income' | 'expense';
          description?: string;
          amount?: number;
          category?: string;
          date?: string;
          project_id?: string | null;
          created_at?: string;
        };
      };
      user_cycles: {
        Row: {
          id: string;
          user_id: string;
          start_date: string;
          end_date: string;
          cycle_number: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          start_date: string;
          end_date: string;
          cycle_number: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          start_date?: string;
          end_date?: string;
          cycle_number?: number;
          created_at?: string;
        };
      };
    };
  };
}