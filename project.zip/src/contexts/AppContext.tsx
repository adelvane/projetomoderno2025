import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { Client, Project, Transaction, Stats } from '../types';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';

interface AppState {
  clients: Client[];
  projects: Project[];
  transactions: Transaction[];
  stats: Stats;
  currentCycle: {
    startDate: Date;
    endDate: Date;
    cycleNumber: number;
  };
  loading: boolean;
  syncing: boolean;
}

type AppAction = 
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_SYNCING'; payload: boolean }
  | { type: 'SET_CLIENTS'; payload: Client[] }
  | { type: 'SET_PROJECTS'; payload: Project[] }
  | { type: 'SET_TRANSACTIONS'; payload: Transaction[] }
  | { type: 'ADD_CLIENT'; payload: Client }
  | { type: 'UPDATE_CLIENT'; payload: Client }
  | { type: 'DELETE_CLIENT'; payload: string }
  | { type: 'ADD_PROJECT'; payload: Project }
  | { type: 'UPDATE_PROJECT'; payload: Project }
  | { type: 'DELETE_PROJECT'; payload: string }
  | { type: 'ADD_TRANSACTION'; payload: Transaction }
  | { type: 'UPDATE_TRANSACTION'; payload: Transaction }
  | { type: 'DELETE_TRANSACTION'; payload: string }
  | { type: 'UPDATE_STATS'; payload: Stats }
  | { type: 'START_NEW_CYCLE' };

const getCurrentCycle = () => {
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  
  return {
    startDate: startOfMonth,
    endDate: endOfMonth,
    cycleNumber: now.getMonth() + 1
  };
};

const initialState: AppState = {
  clients: [],
  projects: [],
  transactions: [],
  stats: {
    totalClients: 0,
    activeProjects: 0,
    completedProjects: 0,
    totalRevenue: 0,
    monthlyRevenue: 0,
    pendingPayments: 0,
  },
  currentCycle: getCurrentCycle(),
  loading: false,
  syncing: false,
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'SET_SYNCING':
      return { ...state, syncing: action.payload };
    case 'SET_CLIENTS':
      return { ...state, clients: action.payload };
    case 'SET_PROJECTS':
      return { ...state, projects: action.payload };
    case 'SET_TRANSACTIONS':
      return { ...state, transactions: action.payload };
    case 'ADD_CLIENT':
      return { ...state, clients: [...state.clients, action.payload] };
    case 'UPDATE_CLIENT':
      return {
        ...state,
        clients: state.clients.map(client =>
          client.id === action.payload.id ? action.payload : client
        ),
      };
    case 'DELETE_CLIENT':
      return {
        ...state,
        clients: state.clients.filter(client => client.id !== action.payload),
      };
    case 'ADD_PROJECT':
      return { ...state, projects: [...state.projects, action.payload] };
    case 'UPDATE_PROJECT':
      return {
        ...state,
        projects: state.projects.map(project =>
          project.id === action.payload.id ? action.payload : project
        ),
      };
    case 'DELETE_PROJECT':
      return {
        ...state,
        projects: state.projects.filter(project => project.id !== action.payload),
      };
    case 'ADD_TRANSACTION':
      return { ...state, transactions: [...state.transactions, action.payload] };
    case 'UPDATE_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.map(transaction =>
          transaction.id === action.payload.id ? action.payload : transaction
        ),
      };
    case 'DELETE_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.filter(transaction => transaction.id !== action.payload),
      };
    case 'UPDATE_STATS':
      return { ...state, stats: action.payload };
    case 'START_NEW_CYCLE':
      return {
        ...state,
        currentCycle: getCurrentCycle(),
      };
    default:
      return state;
  }
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);
  const { authState } = useAuth();

  // Funções para sincronizar com Supabase
  const syncClients = async () => {
    if (!authState.user) return;

    try {
      const { data, error } = await supabase
        .from('clients')
        .select('*')
        .eq('user_id', authState.user.id);

      if (error) throw error;

      const clients: Client[] = data.map(client => ({
        id: client.id,
        name: client.name,
        email: client.email,
        phone: client.phone,
        company: client.company || '',
        address: client.address,
        cnpj: client.cnpj,
        logoUrl: client.logo_url || undefined,
        createdAt: new Date(client.created_at),
        totalProjects: client.total_projects,
        totalRevenue: client.total_revenue,
      }));

      dispatch({ type: 'SET_CLIENTS', payload: clients });
    } catch (error) {
      console.error('Error syncing clients:', error);
    }
  };

  const syncProjects = async () => {
    if (!authState.user) return;

    try {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('user_id', authState.user.id);

      if (error) throw error;

      const projects: Project[] = data.map(project => ({
        id: project.id,
        clientId: project.client_id,
        clientName: project.client_name,
        title: project.title,
        description: project.description,
        status: project.status,
        priority: project.priority,
        value: project.value,
        deadline: new Date(project.deadline),
        createdAt: new Date(project.created_at),
        completedAt: project.completed_at ? new Date(project.completed_at) : undefined,
        paymentReceived: project.payment_received,
        paymentDate: project.payment_date ? new Date(project.payment_date) : undefined,
      }));

      dispatch({ type: 'SET_PROJECTS', payload: projects });
    } catch (error) {
      console.error('Error syncing projects:', error);
    }
  };

  const syncTransactions = async () => {
    if (!authState.user) return;

    try {
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', authState.user.id);

      if (error) throw error;

      const transactions: Transaction[] = data.map(transaction => ({
        id: transaction.id,
        type: transaction.type,
        description: transaction.description,
        amount: transaction.amount,
        category: transaction.category,
        date: new Date(transaction.date),
        projectId: transaction.project_id || undefined,
      }));

      dispatch({ type: 'SET_TRANSACTIONS', payload: transactions });
    } catch (error) {
      console.error('Error syncing transactions:', error);
    }
  };

  // Carregar dados quando usuário faz login
  useEffect(() => {
    if (authState.isAuthenticated && authState.user) {
      dispatch({ type: 'SET_LOADING', payload: true });
      Promise.all([
        syncClients(),
        syncProjects(),
        syncTransactions()
      ]).finally(() => {
        dispatch({ type: 'SET_LOADING', payload: false });
      });
    } else {
      // Limpar dados quando usuário faz logout
      dispatch({ type: 'SET_CLIENTS', payload: [] });
      dispatch({ type: 'SET_PROJECTS', payload: [] });
      dispatch({ type: 'SET_TRANSACTIONS', payload: [] });
    }
  }, [authState.isAuthenticated, authState.user]);

  // Atualizar estatísticas quando dados mudam
  useEffect(() => {
    const cycleTransactions = state.transactions.filter(t => {
      const transactionDate = new Date(t.date);
      return transactionDate >= state.currentCycle.startDate && transactionDate <= state.currentCycle.endDate;
    });

    const stats: Stats = {
      totalClients: state.clients.length,
      activeProjects: state.projects.filter(p => p.status === 'in-progress').length,
      completedProjects: state.projects.filter(p => p.status === 'completed').length,
      totalRevenue: state.transactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0),
      monthlyRevenue: cycleTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0),
      pendingPayments: state.projects
        .filter(p => p.status === 'completed' && !p.paymentReceived)
        .reduce((sum, p) => sum + p.value, 0),
    };

    dispatch({ type: 'UPDATE_STATS', payload: stats });
  }, [state.clients, state.projects, state.transactions, state.currentCycle]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}

// Funções auxiliares para operações CRUD
export const clientOperations = {
  async create(client: Omit<Client, 'id' | 'createdAt' | 'totalProjects' | 'totalRevenue'>) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('clients')
      .insert({
        user_id: user.id,
        name: client.name,
        email: client.email,
        phone: client.phone,
        company: client.company || null,
        address: client.address,
        cnpj: client.cnpj,
        logo_url: client.logoUrl || null,
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      name: data.name,
      email: data.email,
      phone: data.phone,
      company: data.company || '',
      address: data.address,
      cnpj: data.cnpj,
      logoUrl: data.logo_url || undefined,
      createdAt: new Date(data.created_at),
      totalProjects: data.total_projects,
      totalRevenue: data.total_revenue,
    } as Client;
  },

  async update(client: Client) {
    const { error } = await supabase
      .from('clients')
      .update({
        name: client.name,
        email: client.email,
        phone: client.phone,
        company: client.company || null,
        address: client.address,
        cnpj: client.cnpj,
        logo_url: client.logoUrl || null,
        total_projects: client.totalProjects,
        total_revenue: client.totalRevenue,
      })
      .eq('id', client.id);

    if (error) throw error;
  },

  async delete(clientId: string) {
    const { error } = await supabase
      .from('clients')
      .delete()
      .eq('id', clientId);

    if (error) throw error;
  }
};

export const projectOperations = {
  async create(project: Omit<Project, 'id' | 'createdAt'>) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('projects')
      .insert({
        user_id: user.id,
        client_id: project.clientId,
        client_name: project.clientName,
        title: project.title,
        description: project.description,
        status: project.status,
        priority: project.priority,
        value: project.value,
        deadline: project.deadline.toISOString(),
        completed_at: project.completedAt?.toISOString() || null,
        payment_received: project.paymentReceived || false,
        payment_date: project.paymentDate?.toISOString() || null,
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      clientId: data.client_id,
      clientName: data.client_name,
      title: data.title,
      description: data.description,
      status: data.status,
      priority: data.priority,
      value: data.value,
      deadline: new Date(data.deadline),
      createdAt: new Date(data.created_at),
      completedAt: data.completed_at ? new Date(data.completed_at) : undefined,
      paymentReceived: data.payment_received,
      paymentDate: data.payment_date ? new Date(data.payment_date) : undefined,
    } as Project;
  },

  async update(project: Project) {
    const { error } = await supabase
      .from('projects')
      .update({
        client_id: project.clientId,
        client_name: project.clientName,
        title: project.title,
        description: project.description,
        status: project.status,
        priority: project.priority,
        value: project.value,
        deadline: project.deadline.toISOString(),
        completed_at: project.completedAt?.toISOString() || null,
        payment_received: project.paymentReceived || false,
        payment_date: project.paymentDate?.toISOString() || null,
      })
      .eq('id', project.id);

    if (error) throw error;
  },

  async delete(projectId: string) {
    const { error } = await supabase
      .from('projects')
      .delete()
      .eq('id', projectId);

    if (error) throw error;
  }
};

export const transactionOperations = {
  async create(transaction: Omit<Transaction, 'id'>) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('transactions')
      .insert({
        user_id: user.id,
        type: transaction.type,
        description: transaction.description,
        amount: transaction.amount,
        category: transaction.category,
        date: transaction.date.toISOString(),
        project_id: transaction.projectId || null,
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      type: data.type,
      description: data.description,
      amount: data.amount,
      category: data.category,
      date: new Date(data.date),
      projectId: data.project_id || undefined,
    } as Transaction;
  },

  async update(transaction: Transaction) {
    const { error } = await supabase
      .from('transactions')
      .update({
        type: transaction.type,
        description: transaction.description,
        amount: transaction.amount,
        category: transaction.category,
        date: transaction.date.toISOString(),
        project_id: transaction.projectId || null,
      })
      .eq('id', transaction.id);

    if (error) throw error;
  },

  async delete(transactionId: string) {
    const { error } = await supabase
      .from('transactions')
      .delete()
      .eq('id', transactionId);

    if (error) throw error;
  }
};